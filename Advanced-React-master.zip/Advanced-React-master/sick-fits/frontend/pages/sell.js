export default function SellPage() {
  return <p>Hello I am the sell page</p>;
}
