export default function IndexPage() {
  return <div>
    <p>Hello!</p>
  </div>
}
