import Products from '../components/Products';

export default function OrderPage() {
  return (
    <div>
      <Products />
    </div>
  );
}
