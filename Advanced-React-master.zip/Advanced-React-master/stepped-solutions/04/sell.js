export default function SellPage() {
  return <div>
    <p>Hello!</p>
  </div>
}
