export default function OrderPage() {
  return <div>
    <p>Hello!</p>
  </div>
}
