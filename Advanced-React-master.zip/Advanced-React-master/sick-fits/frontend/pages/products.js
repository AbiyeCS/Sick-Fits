export default function ProductPage() {
  return (
    <div>
      <p>Hello!</p>
    </div>
  );
}
