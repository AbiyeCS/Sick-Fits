export default function AccountPage() {
  return (
    <div>
      <p>Hello!</p>
    </div>
  );
}
