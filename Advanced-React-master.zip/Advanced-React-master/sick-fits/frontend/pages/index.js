export default function IndexPage() {
  return <p>Hello!</p>;
}
