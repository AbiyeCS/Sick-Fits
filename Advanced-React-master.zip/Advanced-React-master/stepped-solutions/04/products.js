export default function OrderPage() {
  return <div>
    <p>Hey!</p>
  </div>
}
